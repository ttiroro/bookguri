import React, { Provider } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './pages/Home'
import BookguriInfo from './pages/BookguriInfo'
import MyBooks from './pages/MyBooks'
import BestSeller from './pages/BestSeller'
import Setting from './pages/Setting'
import store from './store';

const App = () => {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home/>} />
          <Route path='/bookguriinfo' element={<BookguriInfo />} />
          <Route path='/mybooks' element={<MyBooks />} />
          <Route path='/bestseller' element={<BestSeller />} />
          <Route path='/setting' element={<Setting />} />
        </Routes>
      </BrowserRouter>
    </Provider>
  )
}

export default App