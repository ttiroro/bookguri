import React from 'react'
import './style/footer.css'

const Footer = () => {
  return (
    <footer>
      <div className='container'>
        footer
      </div>
    </footer>
  )
}

export default Footer