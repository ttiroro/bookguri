import React from 'react'
import './style/HomeBest.css'
import { Link } from 'react-router-dom'
import { IoIosArrowForward, IoIosArrowBack } from "react-icons/io";
import { useSelector } from 'react-redux'

const HomeBest = () => {

  let bestsellerData = useSelector((state)=> {return state.bestsellerData})
  
  return (
    <section className='container'>
        <div className='home-bestseller'>
            <div className='hb-left'>
                <div>
                    <h2 className='hb-title'>베스트 셀러</h2>
                    <p className='hb-text'>이 주의 베스트셀러를 만나보세요!</p>
                    <button type='button' className='hb-btn'>
                        <Link to='/bestseller'>더 보러 가기</Link>
                    </button>
                </div>
                <p className='hb-aladin'>도서 DB 제공 : 알라딘 인터넷서점</p>
            </div>

            <div className='hb-list'>
                <a href="/" className='hb-book'>
                    <img src="/images/book01.jpg" alt="cover" />
                    <div className='hb-book-info'>
                        <p className='hb-book-title'>책 제목</p>
                        <p className='hb-book-author'>지은이</p>
                        <p className='hb-book-heart'>평점</p>
                    </div>
                </a>

                <a href="/" className='hb-book'>
                    <img src="/images/book01.jpg" alt="cover" />
                    <div className='hb-book-info'>
                        <p className='hb-book-title'>책 제목</p>
                        <p className='hb-book-author'>지은이</p>
                        <p className='hb-book-heart'>평점</p>
                    </div>
                </a>

                <a href="/" className='hb-book'>
                    <img src="/images/book01.jpg" alt="cover" />
                    <div className='hb-book-info'>
                        <p className='hb-book-title'>책 제목</p>
                        <p className='hb-book-author'>지은이</p>
                        <p className='hb-book-heart'>평점</p>
                    </div>
                </a>              
            </div>
        <div className='hb-arrow'>
            <IoIosArrowBack className='hb-back'></IoIosArrowBack>
            <IoIosArrowForward className='hb-pre'></IoIosArrowForward>
        </div>
        </div>
    </section>
  )
}

export default HomeBest