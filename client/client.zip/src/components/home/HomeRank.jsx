import React from 'react'
import './style/HomeRank.css'
const HomeRank = () => {
  return (
    <div className='home-rank'>
        <h2>책거리의 독서왕</h2>
    </div>
  )
}

export default HomeRank