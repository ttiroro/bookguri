import React from 'react'

const BestSeller = () => {
  return (
    <div>BestSeller</div>
  )
}

export default BestSeller