import React from 'react'

const BookguriInfo = () => {
  return (
    <div>BookguriInfo</div>
  )
}

export default BookguriInfo