import React from 'react'

const Mybooks = () => {
  return (
    <div>
      <h2>사용자 정보</h2>
      <p>user 이름</p>

    </div>
  )
}

export default Mybooks